import urllib2,json
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BOARD)
GPIO.setup(36, GPIO.OUT)
GPIO.setup(38, GPIO.OUT)
GPIO.setup(40, GPIO.OUT)

while 1:
    results = urllib2.urlopen('http://47.104.28.167/api.json').read()
    status = json.loads(results)['led']
    if status == "red":
        GPIO.output(36, GPIO.HIGH)
        GPIO.output(38, GPIO.LOW)
        GPIO.output(40, GPIO.LOW)
    elif status == "yellow":
        GPIO.output(36, GPIO.LOW)
        GPIO.output(38, GPIO.HIGH)
        GPIO.output(40, GPIO.LOW)
    elif status == "green":
        GPIO.output(36, GPIO.LOW)
        GPIO.output(38, GPIO.LOW)
        GPIO.output(40, GPIO.HIGH)
    else:
        GPIO.output(36, GPIO.LOW)
        GPIO.output(38, GPIO.LOW)
        GPIO.output(40, GPIO.LOW)
